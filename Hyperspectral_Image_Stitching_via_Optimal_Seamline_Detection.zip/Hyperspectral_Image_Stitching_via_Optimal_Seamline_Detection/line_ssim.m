% clc;clear all;close all;
I1 = imread('g092_08.png');
I2 = imread('g092_09.png');
[a,b]=find((seam * 250)==250);
I_line=[a,b];
sum=0;
for i=1:size(I_line,1)
    I_temp1=I1(I_line(i,1)-5:I_line(i,1)+5,I_line(i,2)-5:I_line(i,2)+5);
    I_temp2=I2(I_line(i,1)-5:I_line(i,1)+5,I_line(i,2)-5:I_line(i,2)+5);
  [mssim,~] =  ssim(I_temp1,I_temp2);
  sum=sum+mssim;
end
ssim=sum/size(I_line,1);

