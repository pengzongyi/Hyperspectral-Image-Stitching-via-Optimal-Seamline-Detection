img1 = im2double(imread('g092_08.png'));
w1 = imfill(imbinarize(img1, 0),'holes');
img2 = im2double(imread('g092_09.png'));
w2 = imfill(imbinarize(img2, 0),'holes');
img1 = imread('g092_08.png');
img2 = imread('g092_09.png');
mask1=uint8(w1);mask2=uint8(w2);C=w1.*w2;C=uint8(C);
% Seam Estimation
[msk1, msk2, seam]=SeamEstimation(img1, img2, mask1, mask2);
%% Show result
stitched_image=repmat(uint8(msk1),[1,1,1]).*img1+repmat(uint8(msk2),[1,1,1]).*img2;

stitched_image(stitched_image==0)=255;stitched_image=stitched_image.*C;

figure, imshow(stitched_image);
