# Hyperspectral_Image_Stitching_via_Optimal_Seamline_Detection
Note: code not optimized
% Matlab code and data to reproduce results from the paper                  %
% "Hyperspectral_Image_Stitching_via_Optimal_Seamline_Detection"             %
% Zongyi Peng , Yong Ma , Xiaoguang Mei , Member, IEEE, Jun Huang , and Fan Fan									                    	%
% IEEE GRSL （2022）：10.1109/LGRS.2021.3097394%

